# Fast Carve
Hardsurface utility Blender addon for quick and easy boolean and bevel operations

An introduction video about the idea of Fast Carve can be seen here:

[![Blender Hardsurface Addon and Python Scripting](http://img.youtube.com/vi/5n8o4cVPgv8/0.jpg)](http://www.youtube.com/watch?v=5n8o4cVPgv8 "Blender Hardsurface Addon and Python Scripting")

Here is how to install the addon for Blender 2.8:

[![Blender 2.8 Install Addons : Fast Carve](http://img.youtube.com/vi/14G_YIVdBd0/0.jpg)](https://youtu.be/14G_YIVdBd0 "Blender Blender 2.8 Install Addons : Fast Carve")

If you have installed a previous version of the addon I recommend to:

1. Remove the previous version in the User Preferences
2. Save the Preferences
3. Close and open Blender
4. Install the new version like described in the video above
